# Icone-Iron-Plugins
## Unofficial Icone Iron Plugins  
Used for AutoPlugin By $cripter(https://play.google.com/store/apps/details?id=sites.mjwhitta.scripter)  
Installation files and Guide : &lt;<https://t.me/IronAutoPlugin>&gt;    
  
### Thechnical Info : &lt;<https://github.com/farhamxp/Iron-Pro-Plugins/wiki>&gt;
   
Note : This repository has two branchs. Plugins branch has the last version of each plugin and   
ArchivedPlugin branch has Archives of plugins.
#### These Plugins used in AutoPlugin scripts .It download and install plugins directly from this repository.    
### All plugins uploaded or maked by other friends.   

If everyone wants to create new fork of this repository, it's not problem. But that's fork unusable in AutoPlugin.  
Dear plugin creators : If your output files maked with Thechnical Info structure, that,s usable with AutoPlugin.  
Please tell me to share them with other Icone iron users.  

## License:   
AutoPlugin is licensed under the GNU General Public License (GPL).  This means that is "free software".  
That is, not only can AutoPlugin be downloaded and used at no cost, its source code is also available to be analyzed, modified, and contributed to.  
For more information on the GNU GPL see the GNU website here.&lt;<http://www.gnu.org/licenses/gpl-3.0.txt>&gt;  

## Credits:  
The basic concept of these credits is that the collaborative nature of open-source community has allowed myself to making AutoPluginas a very nice tool.  
  
## SPECIAL THANKS TO SPECIAL PEOPLE :  
### Shahab(t.me/Sky4533)  
### Miles Whittaker (mjwhitta) &lt;<https://mj.whitta.dev>&gt;  
### Mohammad Nasr (MNASR) &lt;<https://oscambinaries.blogspot.com>&gt;  
### popking159

